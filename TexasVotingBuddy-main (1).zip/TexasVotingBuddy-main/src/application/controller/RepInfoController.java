package application.controller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import application.Main;
import application.model.Representative;
import application.model.RepresentativeInfo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class RepInfoController 
{
    @FXML
    private TextArea txtOutput;
    
    @FXML
    private Button backButton;
    
    @FXML
    private Button homeButton;
    
    @FXML
    private TableView<Representative> repTableView;
    @FXML
    private TableColumn<Representative, String> repImage;
    @FXML
    private TableColumn<Representative, String> repName;
    @FXML
    private TableColumn<Representative, String> repParty;
    @FXML
    private TableColumn<Representative, String> repOffice;
    @FXML
    private TableColumn<Representative, String> repDivision;
    @FXML
    private TableColumn<Representative, String> repURL;
    @FXML
    private TableColumn<Representative, String> repEmail;
    @FXML
    private TableColumn<Representative, String> repChannel;
    
    
    private final ObservableList<Representative> data = FXCollections.observableArrayList();
    
    
    @FXML
    void backScreen(ActionEvent event) {
		
    	Parent root;
		try
    	{
			root = FXMLLoader.load(Main.class.getResource("view/Address.fxml"));
	    	Main.stage.setScene( new Scene(root));
	    	Main.stage.show();
    	}
    	catch (IOException e) 
		{
			e.printStackTrace();
		}
    }
    
    @FXML
    void homeScreen(ActionEvent event) {
		
    	Parent root;
		try
    	{
			root = FXMLLoader.load(Main.class.getResource("view/Splash.fxml"));
	    	Main.stage.setScene( new Scene(root));
	    	Main.stage.show();
    	}
    	catch (IOException e) 
		{
			e.printStackTrace();
		}
    }
    
    @FXML
    public void initialize() 
    {

    	repImage.setCellValueFactory(new PropertyValueFactory<>("photo"));
    	
    	repName.setCellValueFactory(new PropertyValueFactory<Representative, String>("repName"));
    	
    	repParty.setCellValueFactory(new PropertyValueFactory<>("repParty"));
    	
    	repOffice.setCellValueFactory(new PropertyValueFactory<>("repOffice"));
    	
    	repDivision.setCellValueFactory(new PropertyValueFactory<>("repDivision"));
    	
    	repURL.setCellValueFactory(new PropertyValueFactory<>("repURL"));
    	
    	repEmail.setCellValueFactory(new PropertyValueFactory<>("repEmail"));
    	
    	repChannel.setCellValueFactory(new PropertyValueFactory<>("repChannel"));
    	
    	RepresentativeInfo repNew = RepresentativeInfo.repCurrent;
		
		for (int i = 0 ; i < repNew.getOfficials().size(); i++)
		{
			
			ImageView repPhoto = new ImageView();
			repPhoto.setFitWidth(80);
			repPhoto.setFitHeight(80);
			Image imageFromURL;
			try {
				imageFromURL = new Image(new FileInputStream(repNew.getOfficials().get(i).getPhotoLocation()));
				repPhoto.setImage(imageFromURL);
			} catch (FileNotFoundException e) {
				e.printStackTrace();
			}
			Representative tempRep = new Representative(repPhoto, repNew.getOfficials().get(i).getName(), repNew.getOfficials().get(i).getParty(), repNew.getOfficials().get(i).getOffices().get(0).getName(), 
					repNew.getOfficials().get(i).getOffices().get(0).getDivisions().get(0).getName(), repNew.getOfficials().get(i).URLToString(), 
					repNew.getOfficials().get(i).emailToString(), repNew.getOfficials().get(i).channelToString());
			data.add(tempRep);
		}
		
		repTableView.setItems(data);
		
		
		
 

    }
}
