package application.controller;

import java.io.IOException;

import application.Main;
import application.model.Election;
import application.model.ElectionObj;
import application.model.Representative;
import application.model.RepresentativeInfo;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextArea;
import javafx.scene.control.cell.PropertyValueFactory;
/**
 * calls toString of Poll and Contest to retrieve the date, and print it out onto a TextArea
 *
 * @author Diego Enriquez (dyg458)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/29/22
 */

public class ElectionInfoController {
	/**
	 * Buttons to either go to prev screen or the home (splash) GUI(s)
	 * TableView to setup Table and view the election data
	 * TableColumn per variable of election data
	 * Label to view general info of the election and/or poll location according to County
	 * ObservableList to populate the TableView using parameter ElectionObj 
	 */
	@FXML
    private Button backButton;
	
    @FXML
    private Button homeButton;
	
    @FXML
    private TableView<ElectionObj> elecTableView;
    
    @FXML
    private TableColumn<ElectionObj, String> elecAddress;
    
    @FXML
    private TableColumn<ElectionObj, String> elecPollingHours;
    
    @FXML
    private TableColumn<ElectionObj, String> elecCoordinates;
    
    @FXML
    private TableColumn<ElectionObj, String> elecStartDate;
    
    @FXML
    private TableColumn<ElectionObj, String> elecEndDate;
    
    @FXML
    private TableColumn<ElectionObj, String> repChannel;
    
    @FXML
    private Label GenInfoLabel;
    
    private final ObservableList<ElectionObj> data = FXCollections.observableArrayList();
    
    /**
     * @param event
     * 
     * configure back button event, loads back to previous fxml which is Address.fxml
     */
    @FXML
    void backScreen(ActionEvent event) {
		
    	Parent root;
		try
    	{
			root = FXMLLoader.load(Main.class.getResource("view/Address.fxml"));
	    	Main.stage.setScene( new Scene(root));
	    	Main.stage.show();
    	}
    	catch (IOException e) 
		{
			e.printStackTrace();
		}
    }
    
    /**
     * @param event
     * 
     * home screen button event, loads back to home fxml, which is Splash.fxml
    /**
     * @param event
     */
    @FXML
    void homeScreen(ActionEvent event) {
		
    	Parent root;
		try
    	{
			root = FXMLLoader.load(Main.class.getResource("view/Splash.fxml"));
	    	Main.stage.setScene( new Scene(root));
	    	Main.stage.show();
    	}
    	catch (IOException e) 
		{
			e.printStackTrace();
		}
    }
    
    /**
     *  Initialize to load cells with variables upon the time User is viewing the GUI
     *  Create an elecNew variable to iterate through for each election event
     *  Sets label text to the associated general info (voterServices) for the election
     *  (for loop) iterates through elecNew array
     *  Concatenate longitude and latitude to create coordinates
     *  Use constructor to create an Election object, provide it with parameters for Address, PollHours, Coordinates
     *  StartDate, and EndDate. This data is loaded by using the getters for the associated variables as well as a getter
     *  to return the specified element of the list.
     *  add the election object to the observable list
     *  Set the TableView contents (items) with the ObservableList data
     *
     * @param event
     */
    @FXML
    public void initialize() 
    { 
    	elecAddress.setCellValueFactory(new PropertyValueFactory<>("elecAddress"));

    	elecPollingHours.setCellValueFactory(new PropertyValueFactory<>("elecPollingHours"));

    	elecCoordinates.setCellValueFactory(new PropertyValueFactory<>("elecCoordinates"));

    	elecStartDate.setCellValueFactory(new PropertyValueFactory<>("elecStartDate"));

    	elecEndDate.setCellValueFactory(new PropertyValueFactory<>("elecEndDate"));

    	Election elecNew = Election.elecCurrent;

    	GenInfoLabel.setText(elecNew.getPollLocation().get(0).getNotes() + " " + elecNew.getPollLocation().get(0).getVoterServices());
    	
    	for(int i = 0; i < elecNew.getPollLocation().size(); i++)
    	{
    		String longitude = String.valueOf(elecNew.getPollLocation().get(i).getLongitude());
    		String latitude = String.valueOf(elecNew.getPollLocation().get(i).getLatitude());
    		String coordinates = latitude + " " + longitude;
    		ElectionObj tempElec = new ElectionObj(elecNew.getPollLocation().get(i).getAddresses().get(0).toString(), elecNew.getPollLocation().get(i).getPollingHours(), coordinates, elecNew.getPollLocation().get(i).getStartDate(), elecNew.getPollLocation().get(i).getEndDate());   
    		data.add(tempElec);
    	}
    	elecTableView.setItems(data);
    }
}
