package application.controller;

import java.io.File;
import java.io.IOException;
import java.util.Scanner;

import org.json.JSONObject;

import application.Main;
import application.handler.APIHandler;
import application.model.Election;
import application.model.Official;
import application.model.RepresentativeInfo;
import javafx.application.Platform;
import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.shape.Line;
import javafx.scene.web.WebView;

public class AddressController   
{
	static public Task<Integer> task;
	static private boolean blnValidAddress;
    @FXML
    private TextField txtAddress;
    
    @FXML
    private WebView webMap;
    
    @FXML
    private Button btnConfirmAddress;

    @FXML
    private Label lblAddressInfo;

    @FXML
    private Button btnGetElectionInfo;

    @FXML
    private Button btnGetReps;
    
    @FXML
    private Button btnAdvanceSearch;
    
    @FXML
    private Label advSearchLabel;
    
    @FXML
    private Line advSearchLine;
    
    @FXML
    private Button btnGetRepsUS;
    
    @FXML
    private Button btnGetRepsTX;
    
    @FXML
    private Button btnGetRepsLocal;
    
    @FXML
    private Button backButton;

    @FXML
    void OnInput(ActionEvent event) 
    {
    	System.out.println("Starting task");
	   	lblAddressInfo.setText("Checking Address");
	   	
	   		if (task != null && task.isRunning())
	   		{
	   			task.cancel();
	   		}
	   		task = new Task<Integer>() {
            @Override protected Integer call() throws Exception {
            	try {
        			blnValidAddress = APIHandler.checkAddress(txtAddress.getText());
        	    	if(!blnValidAddress)
        	    	{
        	    		System.out.println("invalid Address");
                    		Platform.runLater(new Runnable() 
                    		{
                            @Override public void run() 
                            {
                   	   		 lblAddressInfo.setText("That address did not work");
                	   		 btnGetElectionInfo.setDisable(true);
                	   		 btnGetReps.setDisable(true);
                	   		 btnAdvanceSearch.setDisable(true);
                            }});// end of run later
        	    	
        	    	}
        	    	else
        	    	{
        	    		System.out.println("Valid Address");
        	    		
                        Platform.runLater(new Runnable() 
                    	{
                        @Override public void run() {
        	    		lblAddressInfo.setText("Valid Address Loading info");
                        }});// end of run later
                        System.out.println("Running API Request");
           	   		 	JSONObject jsnData = APIHandler.getRepoInfo(txtAddress.getText());
        	   		 	RepresentativeInfo.repCurrent = new RepresentativeInfo(jsnData);
        	   		 	System.out.println("API Request Completed");
        	   		 
                        Platform.runLater(new Runnable() 
                    	{
                        @Override public void run() 
                        {
        	    		lblAddressInfo.setText("Info Loaded");
        	   		 	btnGetElectionInfo.setDisable(false);
        	   		 	btnGetReps.setDisable(false);
        	   		 	btnAdvanceSearch.setDisable(false);
                        }});// end of run later
        	    	}
            	}//end of try
        	    	catch (IOException e) 
            	{
        			// TODO Auto-generated catch block
        			e.printStackTrace();
        		}
                return 1;
            }//end of call()
        };//end of task
        Thread thread = new Thread(task);
        thread.setDaemon(true);
        thread.start();


    }
    
    @FXML
    void AdvancedSearch(ActionEvent event) {
    	
    	btnGetRepsUS.setVisible(true);
    	btnGetRepsTX.setVisible(true);
    	btnGetRepsLocal.setVisible(true);
    	advSearchLine.setVisible(true);
    	advSearchLabel.setVisible(true);
    	
    }
    
    @FXML
    void GetRepsUS(ActionEvent event) {
    		RepresentativeInfo repDivision = RepresentativeInfo.repCurrent;
        	 for(int i = 0; i < repDivision.getOfficials().size(); i++) {
        		 String strCompare = repDivision.getOfficials().get(i).getOffices().get(0).getDivisions().get(0).getName();
        		 if(!strCompare.equals("United States")) {
        			 repDivision.getOfficials().remove(i);
        			 i--;
        		 }
        	 }
        	 RepresentativeInfo.repCurrent = repDivision;
        	 MovetoRepsInfo();
    	
    }
    
    @FXML
    void getRepsTX(ActionEvent event) {
    	
    		RepresentativeInfo repDivision = RepresentativeInfo.repCurrent;
        	 for(int i = 0; i < repDivision.getOfficials().size(); i++) {
        		 String strCompare = repDivision.getOfficials().get(i).getOffices().get(0).getDivisions().get(0).getName();
        		 if(!strCompare.equals("Texas")) {
        			 repDivision.getOfficials().remove(i);
        			 i--;
        		 }
        	 }
        	 RepresentativeInfo.repCurrent = repDivision;
        	 MovetoRepsInfo();
    	
    }
    
    @FXML
    void getRepsLocal(ActionEvent event) {
    	
    		RepresentativeInfo repDivision = RepresentativeInfo.repCurrent;
        	 for(int i = 0; i < repDivision.getOfficials().size(); i++) {
        		 String strCompare = repDivision.getOfficials().get(i).getOffices().get(0).getDivisions().get(0).getName();
        		 if(strCompare.equals("United States") || strCompare.equals("Texas")) {
        			 repDivision.getOfficials().remove(i);
        			 i--;
        		 }
        	 }
        	 RepresentativeInfo.repCurrent = repDivision;
        	 MovetoRepsInfo();

    	
    }
    
    @FXML
    void GetRepsInfo(ActionEvent event) 
    {   		  
    	MovetoRepsInfo();
    }

    void MovetoRepsInfo()
    {
        if(RepresentativeInfo.repCurrent != null)
    	{
        	task = new Task<Integer>() {
                @Override protected Integer call() throws Exception 
                {
                    Platform.runLater(new Runnable() 
                 	{
                     @Override public void run() 
                     {
     	    		lblAddressInfo.setText("Loading Reps please wait");
     	   		 	btnGetElectionInfo.setDisable(true);
     	   		 	btnGetReps.setDisable(true);
     	   		 	btnAdvanceSearch.setDisable(true);
                     }});// end of run later
                	
        	   		for(Official off : RepresentativeInfo.repCurrent.getOfficials()) 
    	   			{
    	   				System.out.println(off.getName());
    	   				off.DownloadPhoto();
    	   			}

                    Platform.runLater(new Runnable() 
                 	{
                     @Override public void run() 
                     {
                     	try 
                    	{

                    	Parent root;

                			root = FXMLLoader.load(Main.class.getResource("view/RepInfo.fxml"));
                	    	Main.stage.setScene( new Scene(root));
                	    	Main.stage.show();
                		} 
                		catch (IOException e) 
                		{
                			e.printStackTrace();
                		}
                     	
                     }});// end of run later
        	   		
        	   		return 1;
        	   		
        	   		
                }};//end of task
        	

                Thread thread = new Thread(task);
                thread.setDaemon(true);
                thread.start();	
        }//end of if
    }
    @FXML
    void GetElectionInfo(ActionEvent event) 
    {
    	String file = "check/electiondata.json";
    	String buffer = "";
		try 
		{  
			
			Scanner scan = null;
			

			try {
				scan = new Scanner(new File(file));

				while (scan.hasNextLine()) {

					String line = scan.nextLine();

					if (line != null) {
						
					  buffer += line;
						
					}

				}

			} catch (IOException e) {
				e.printStackTrace();
			}

			if (scan != null) {
				scan.close();
			}
			//toggle breakpoint
			JSONObject jsnData = new JSONObject(buffer);
			  //APIHandler.getElectionInfo(txtAddress.getText()); //sends address, returns json object
			/*if(jsnData == null)
			{
				lblAddressInfo.setText("That address did not work");
				return;
			}
			*/
			Election.elecCurrent = new Election(jsnData);
						
		Parent root;
		
			root = FXMLLoader.load(Main.class.getResource("view/ElectionInfo.fxml"));
	    	Main.stage.setScene( new Scene(root));
	    	Main.stage.show();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}
    }
    
    @FXML
    void backScreen(ActionEvent event) {
		
    	Parent root;
		try
    	{
			root = FXMLLoader.load(Main.class.getResource("view/Splash.fxml"));
	    	Main.stage.setScene( new Scene(root));
	    	Main.stage.show();
    	}
    	catch (IOException e) 
		{
			e.printStackTrace();
		}
    }
    
    @FXML
    public void initialize() 
    {
  		 btnGetElectionInfo.setDisable(true);
  		 btnGetReps.setDisable(true);
  		 btnAdvanceSearch.setDisable(true);
  		 
  		btnGetRepsUS.setVisible(false);
    	btnGetRepsTX.setVisible(false);
    	btnGetRepsLocal.setVisible(false);
    	advSearchLine.setVisible(false);
    	advSearchLabel.setVisible(false);
    }
}
