package application.controller;

import java.io.IOException;

import application.Main;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;

public class SplashController 
{

    @FXML
    private Button btnEnter;

    @FXML
    void Enter(ActionEvent event) 
    {
    	Parent root;
		try 
		{
			root = FXMLLoader.load(Main.class.getResource("view/Address.fxml"));
	    	Main.stage.setScene( new Scene(root));
	    	Main.stage.show();
		} 
		catch (IOException e) 
		{
			e.printStackTrace();
		}


    }
    
}
