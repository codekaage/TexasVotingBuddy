package application.handler;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Iterator;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Main method
 * 
 * @author Andrew Neumann (obb447)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/9/22
 */

public class APIHandler 
{

	private static final String USER_AGENT = "Mozilla/5.0";
	private static final String API_KEY  = "AIzaSyB7hOPQJsEL8UEDp1YPaVcA2kaUp3CNdRM";
	private static final String API_KEY_MAPS = "AIzaSyCLp_IKvmynDIfqfMjAKPswDBMuOd4YbC8";

	/**
	* Returns an JSON object that can then be turned into a Representatives object
	* The strAddress argument must specify a valid American Address.
	* 
	* @param  	strAddress location for query 
	* @return      JSONObject that represents the election data for a specified address
	*/
	public static JSONObject getRepoInfo(String strAddress) throws IOException 
	{

		//https://civicinfo.googleapis.com/civicinfo/v2/representatives?address=113%20armour%20pl&key=AIzaSyB7hOPQJsEL8UEDp1YPaVcA2kaUp3CNdRM
		String strGetUrl= String.format("https://civicinfo.googleapis.com/civicinfo/v2/representatives?address=%s&key=%s",toURLFormat(strAddress) ,API_KEY);
		
		URL obj = new URL(strGetUrl);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		con.setRequestProperty("User-Agent", USER_AGENT);
		int responseCode = con.getResponseCode();
		
		if (responseCode == HttpURLConnection.HTTP_OK) 
			{ 
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

			while ((inputLine = in.readLine()) != null) 
			{
				response.append(inputLine);
			}
			in.close();
			return new JSONObject(response.toString());
			
			}
			
			else 
			{
				System.out.println("GET request not worked");
				return null;
			}

	}

	/**
	* Returns an JSON object that can then be turned into a Election object 
	* The strAddress argument must specify a valid American Address.
	* 
	* @param  strAddress location for query 
	* @return      JSONObject that represents the election data for a specified address
	*/
	public static JSONObject getElectionInfo(String strAddress) throws IOException 
	{
		String strGetURL= String.format("https://www.googleapis.com/civicinfo/v2/voterinfo?address=%s&key=%s",toURLFormat(strAddress) ,API_KEY);
		URL obj = new URL(strGetURL);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		con.setRequestProperty("User-Agent", USER_AGENT);
		int responseCode = con.getResponseCode();
	
		if (responseCode == HttpURLConnection.HTTP_OK) 
		{ 
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) 
			{
				response.append(inputLine);
			}
		in.close();
		//read data hard-coded; electiondata.json
		
		return new JSONObject(response.toString());
		
		}//end of if block
		
		else 
		{
			System.out.println("GET request not worked");
			return null;
		}

	}
	

	/**
	 * @param strName Name of article to look for photo
	 * @return returns the URL address of Photo or Null if PhotoURL not found
	 */
	public static String optGetPhotoURLFromWiki(String strName) throws IOException 
	{
		String strGetURL= String.format("https://en.wikipedia.org/w/api.php?action=query&prop=pageimages&format=json&piprop=original&titles=%s",toURLFormat(strName) );
		URL obj = new URL(strGetURL);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		con.setRequestProperty("User-Agent", USER_AGENT);
		int responseCode = con.getResponseCode();
	
		if (responseCode == HttpURLConnection.HTTP_OK) 
		{ 
			BufferedReader in = new BufferedReader(new InputStreamReader(con.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) 
		{
			response.append(inputLine);
		}
		in.close();
		JSONObject jsnPages = new JSONObject(response.toString()).getJSONObject("query").getJSONObject("pages");
		String strFirstKey = jsnPages.keys().next().toString();
		JSONObject jsnPage = jsnPages.getJSONObject(strFirstKey);
		JSONObject jsnOriginal = jsnPage.optJSONObject("original");
				if(jsnOriginal != null)
				{
					return jsnOriginal.optString("source");
				}
		
		}
		
		else 
		{
			System.out.println("GET request not worked");
			return null;
		}
	return null;
	}
	
	/**
	 * @param strString
	 * @return Returns a String that can be placed in URLFormat
	 */
	private static String toURLFormat(String strString)
	{
		try 
		{
			return URLEncoder.encode(strString, StandardCharsets.UTF_8.toString());
		} 
		catch (UnsupportedEncodingException e) 
		{
			e.printStackTrace();
		}
		return null;

	}
	
	
	public static boolean checkAddress(String strAddress) throws IOException 
	{
		String strGetUrl= String.format("https://www.googleapis.com/civicinfo/v2/voterinfo?returnAllAvailableData=true&address=%s&key=%s",toURLFormat(strAddress) ,API_KEY);
		
		URL obj = new URL(strGetUrl);
		HttpURLConnection con = (HttpURLConnection) obj.openConnection();
		con.setRequestMethod("GET");
		con.setRequestProperty("User-Agent", USER_AGENT);
		int responseCode = con.getResponseCode();
		
		if (responseCode == HttpURLConnection.HTTP_OK) 
			{ 
			return true;
			
			}
			
			else 
			{
				return false;
			}
	}
}
