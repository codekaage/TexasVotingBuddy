package application;
	
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;


public class Main extends Application {
		public static Stage stage;
		@Override
		public void start(Stage primaryStage) {
			try {
				// Connect to the FXML (contains our layout) and load it in
				FXMLLoader loader = new FXMLLoader();
				loader.setLocation( Main.class.getResource("view/Splash.fxml") );
				AnchorPane layout = (AnchorPane) loader.load();
				
				// Put the layout onto the scene
				Scene scene = new Scene( layout );
				
				// Set the scene on the stage
				primaryStage.setTitle("Texas Voting Buddy");
				primaryStage.setScene(scene);
				primaryStage.show();
				Main.stage = primaryStage;
				
			} catch(Exception e) {
				e.printStackTrace();
			}
		}
		
		public static void main(String[] args) {
			launch(args);
		}
	}
