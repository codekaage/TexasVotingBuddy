package application.model;

import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;

import application.handler.APIHandler;

/**
 * The Official object contains the Official's name and party.
 * As well as 4 ArrayLists of Roles, Urls, Channels, and offices.
 *
 * @author Andrew Neumann (obb447)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/9/22
 */

public class Official 
{
	private String strName;
	private String strParty;
	private String strPhotoURL;
	private ArrayList<String> arrRole;
	private ArrayList<String> arrURL;
	private ArrayList<String> arrEmails;
	private String strPhotoLocation;


	private ArrayList<Channel> arrChannels;
	private ArrayList<Office> arrOffices;
	private JSONObject jsnDataSource ;
	
	public Official()
	{
		setRole(new ArrayList<String>());
		arrURL = new ArrayList<String>();
		arrEmails = new ArrayList<String>();
		arrChannels = new ArrayList<Channel>();
		setOffices(new ArrayList<Office>());
	}
	
	public Official(JSONObject jsnData)
	{
		setRole(new ArrayList<String>());
		arrURL = new ArrayList<String>();
		arrChannels = new ArrayList<Channel>();
		setOffices(new ArrayList<Office>());
		arrEmails = new ArrayList<String>();

		setDataSource(jsnData);
		
		setName(jsnData.getString("name"));
		setParty(jsnData.getString("party"));
		
		if(jsnData.has("urls"))
		{
			JSONArray jsnURLS = jsnData.getJSONArray("urls");
			for (int x = 0; x < jsnURLS.length(); x++) 
			{
				arrURL.add(jsnURLS.getString(x));
			}
		}
		
		if(jsnData.has("emails"))
		{
			JSONArray jsnEmails = jsnData.getJSONArray("emails");
			for (int x = 0; x < jsnEmails.length(); x++) 
			{
				arrEmails.add(jsnEmails.getString(x));
			}
		}
		
		if(jsnData.has("photoUrl"))
		{
			strPhotoURL = jsnData.optString("photoUrl");
		}
		
		if(jsnData.has("channels"))
		{	
			JSONArray jsnChannels = jsnData.optJSONArray("channels");
			for (int x = 0; x < jsnChannels.length(); x++) 
			{
				arrChannels.add(new Channel(jsnChannels.getJSONObject(x)));
			}
		}
		fetchURLIfNone();

	}
	
	private void fetchURLIfNone()
	{
		if(getPhotoURL() == null)
		{

			for (int i = 0; i < getURLs().size(); i++)
			{
				if(getURLs().get(i).contains("wikipedia"))
				{
					int check = getURLs().get(i).lastIndexOf("https://en.wikipedia.org/wiki/");
					if(check > -1)
					{
						String strArticleName = getURLs().get(i).substring(30);
						try 
						{
							setPhotoURL(APIHandler.optGetPhotoURLFromWiki(strArticleName));
						} 
						catch (IOException e) 
						{
							e.printStackTrace();
						}
					}
					
				}
			}
		}

		
	}
	/**
	 * Downloads the PhotoURL to a temp directory
	 */
	public void DownloadPhoto()
	{
		if(getName().contains("Dan Patrick"))
		{
			//Dan Patrick's site is garbage, so I needed to make this exception.
			setPhotoURL(null);
			fetchURLIfNone();
		}
		if(getPhotoURL()== null)
		{
			setPhotoLocation("Images/no-image.png");
			return;
		}
        try {
        	String tempFileName = getName().replaceAll("\\s", "").replaceAll("\\.", "") + "." + getPhotoURLExtension();
            Path temp = Files.createTempFile("", tempFileName);

            String absolutePath = temp.toString();
            setPhotoLocation(absolutePath);
        	
        	URL url = new URL(getPhotoURL());
        	HttpURLConnection hc = (HttpURLConnection) url.openConnection();
        	hc.setRequestMethod("GET");
        	hc.addRequestProperty("User-Agent","Mozilla/5.0");
        	hc.setReadTimeout(4000);
        	int responseCode = hc.getResponseCode();
        	if(responseCode == 429)
        	{
        		Thread.sleep(500);
            	hc = (HttpURLConnection) url.openConnection();
            	hc.setRequestMethod("GET");
            	hc.addRequestProperty("User-Agent","Mozilla/5.0");
            	hc.setReadTimeout(4000);
        	}
        	InputStream in = new BufferedInputStream(url.openStream());
        	ByteArrayOutputStream out = new ByteArrayOutputStream();
        	byte[] buf = new byte[1024];
        	int n = 0;
        	while (-1!=(n=in.read(buf)))
        	{
        	   out.write(buf, 0, n);
        	}
        	out.close();
        	in.close();
        	byte[] response = out.toByteArray();
        	FileOutputStream fos = new FileOutputStream(absolutePath);
        	fos.write(response);
        	fos.close();

        } 
        catch (IOException | InterruptedException e) 
        {
        	System.out.print("No Photo " + getName());
            e.printStackTrace();
            
  
        }

	}
	/**
	 * @return the arrEmails
	 */
	public ArrayList<String> getEmails() {
		return arrEmails;
	}
	
	private String getPhotoURLExtension()
	{
		if(getPhotoURL() == null)
		{
			return null;
		}
		String strs[] = getPhotoURL().split("\\.");
		return strs[strs.length-1]; 
	}

	/**
	 * @param arrEmails the arrEmails to set
	 */
	public void setEmails(ArrayList<String> arrEmails) {
		this.arrEmails = arrEmails;
	}
	
	/**
	 * toString method for Email Array
	 * 
	 * @author Ryan Brown (kkw582)
	 * 
	 * @return strOut - String representation of arrEmails
	 */
	public String emailToString() 
	{
		String strOut = "";
		for(int i = 0; i < arrEmails.size(); i++) {
			strOut += arrEmails.get(i) + "\n";
		}
		return strOut;	
	}
	
	/**
	 * @return the jsnDataSource
	 */
	public JSONObject getDataSource() {
		return jsnDataSource;
	}

	/**
	 * @param jsnDataSource the jsnDataSource to set
	 */
	private void setDataSource(JSONObject jsnDataSource) {
		this.jsnDataSource = jsnDataSource;
	}

	/**
	 * @return the arrOffices
	 */
	public ArrayList<Office> getOffices() {
		return arrOffices;
	}

	/**
	 * @param arrOffices the arrOffices to set
	 */
	public void setOffices(ArrayList<Office> arrOffices) {
		this.arrOffices = arrOffices;
	}
	
	/**
	 * @param arrOffice to add to arrOffices
	 */
	public void addOffice(Office newOffice) {
		this.arrOffices.add(newOffice);
	}

	/**
	 * @return the strParty
	 */
	public String getParty() {
		return strParty;
	}

	/**
	 * @param strParty the strParty to set
	 */
	public void setParty(String strParty) {
		this.strParty = strParty;
	}

	/**
	 * @return the arrRole
	 */
	public ArrayList<String> getRole() {
		return arrRole;
	}

	/**
	 * @param arrRole the arrRole to set
	 */
	public void setRole(ArrayList<String> arrRole) {
		this.arrRole = arrRole;
	}
	
	/**
	 * @return the arrRole
	 */
	public ArrayList<Channel> getChannels() {
		return arrChannels;
	}
	
	/**
	 * toString method for Channel Array
	 * 
	 * @author Ryan Brown (kkw582)
	 * 
	 * @return strOut - String representation of arrChannels
	 */
	public String channelToString() 
	{
		String strOut = "";
		for(int i = 0; i < arrChannels.size(); i++) {
			strOut += arrChannels.get(i) + "\n";
		}
		return strOut;	
	}
	
	/**
	 * @return the strName
	 */
	public String getName() {
		return strName;
	}

	/**
	 * @param strName the strName to set
	 */
	public void setName(String strName) {
		this.strName = strName;
	}
	
	/**
	 * @return the strName
	 */
	public ArrayList<String> getURLs() {
		return arrURL;
	}

	/**
	 * @param strName the strName to set
	 */
	public void setURL(ArrayList<String> arrURL) {
		this.arrURL = arrURL;
	}
	
	/**
	 * toString method for URL Array
	 * 
	 * @author Ryan Brown (kkw582)
	 * 
	 * @return strOut - String representation of arrURL
	 */
	public String URLToString() 
	{
		String strOut = "";
		for(int i = 0; i < arrURL.size(); i++) {
			strOut += arrURL.get(i) + "\n";
		}
		return strOut;	
	}
	
	public String toString()
	{
		String strOut = "";
		String strTab = "\t";
		strOut += "Name: " + getName() + "\n"; 
		strOut += "Party: " + getParty() + "\n";
		strOut += "Photo URL: " + getPhotoURL() + "\n";
		if(getOffices().size() > 0)
		{strOut += "Offices:\n";
		for (int i = 0; i< getOffices().size(); i++)
			{
			strOut += strTab +getOffices().get(i) + "\n";
			}
		}
		if(getURLs() != null && getURLs().size() > 0)
			{strOut += "URLs:\n";
			for (int i = 0; i< getURLs().size(); i++)
				{
				strOut += strTab +getURLs().get(i) + "\n";
				}
			}
		
		if(getChannels() != null && getChannels().size() > 0)
		{strOut += "Channels:\n";
		for (int i = 0; i< getChannels().size(); i++)
			{
			strOut += strTab +getChannels().get(i) + "\n";
			}}
		
		if(getEmails() != null &&getEmails().size() > 0)
		{strOut += "Emails:\n";
		for (int i = 0; i< getEmails().size(); i++)
			{
			strOut += strTab +getEmails().get(i) + "\n";
			}}
		
		return strOut;
		
	}

	/**
	 * @return the strPhotoURL
	 */
	public String getPhotoURL() {
		return strPhotoURL;
	}

	/**
	 * @param strPhotoURL the strPhotoURL to set
	 */
	public void setPhotoURL(String strPhotoURL) {
		this.strPhotoURL = strPhotoURL;
	}

	/**
	 * @return the strPhotoLocation
	 */
	public String getPhotoLocation() {
		return strPhotoLocation;
	}

	/**
	 * @param strPhotoLocation the strPhotoLocation to set
	 */
	public void setPhotoLocation(String strPhotoLocation) {
		this.strPhotoLocation = strPhotoLocation;
	}
}

