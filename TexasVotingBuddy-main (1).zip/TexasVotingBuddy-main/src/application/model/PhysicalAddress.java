package application.model;

import org.json.JSONObject;

public class PhysicalAddress {

     private String locationName;
     private String line1;
     private String city;
     private String state;
     private String zip;
	
	public PhysicalAddress(JSONObject jsnphyAddress) {
		
		this.locationName = jsnphyAddress.optString("locationName");
		this.line1 = jsnphyAddress.optString("line1");
		this.city = jsnphyAddress.optString("city");
		this.state = jsnphyAddress.optString("state");  //FIXME
		this.zip = jsnphyAddress.optString("zip");
		
		
		
		
		
		
	}

	/**
	 * @return the locationName
	 */
	public String getLocationName() {
		return locationName;
	}

	/**
	 * @param locationName the locationName to set
	 */
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	/**
	 * @return the line1
	 */
	public String getLine1() {
		return line1;
	}

	/**
	 * @param line1 the line1 to set
	 */
	public void setLine1(String line1) {
		this.line1 = line1;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}

	/**
	 * @param zip the zip to set
	 */
	public void setZip(String zip) {
		this.zip = zip;
	}
	public String toString()
	{
       return "BRUH" + this.getLocationName() + " " + this.getLine1() + "\n" 
    		   + this.getCity() + " " + this.getState() + " " + this.getZip();
		
	}
}
