package application.model;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
/**
 * Sorts Data into objects and toString()
 *
 * @author Diego Enriquez (dyg458)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/29/22
 */
public class Poll {

	private String notes;
	private String pollingHours;
	private String name;
	private String voterServices;
	private String startDate;
	private String endDate;
	private double latitude;
	private double longitude;
	private ArrayList<Address> addresses = new ArrayList<Address>();
	
	
	/**
	 * @param jsnData
	 */
	public Poll(JSONObject jsnData) {
		
		JSONObject jsnAddress = jsnData.getJSONObject("address");
		Address address = new Address(jsnAddress); //get address object from Poll
		addresses.add(address); //adding to arrayList instead
		
		this.notes = jsnData.optString("notes");
		this.pollingHours= jsnData.optString("pollingHours");
		this.name = jsnData.optString("name");
		this.voterServices = jsnData.optString("voterServices");
		this.endDate = jsnData.optString("zip");
		this.latitude = jsnData.optDouble("latitude");
		this.longitude = jsnData.optDouble("longitude");	
		this.startDate = jsnData.optString("startDate");
		this.endDate = jsnData.optString("endDate");
		
	}

	/**
	 * @return the addresses
	 */
	public ArrayList<Address> getAddresses() {
		return addresses;
	}

	/**
	 * @param addresses the addresses to set
	 */
	public void setAddresses(ArrayList<Address> addresses) {
		this.addresses = addresses;
	}

	/**
	 * @return the notes
	 */
	public String getNotes() {
		return notes;
	}

	/**
	 * @param notes the notes to set
	 */
	public void setNotes(String notes) {
		this.notes = notes;
	}

	/**
	 * @return the pollingHours
	 */
	public String getPollingHours() {
		return pollingHours;
	}

	/**
	 * @param pollingHours the pollingHours to set
	 */
	public void setPollingHours(String pollingHours) {
		this.pollingHours = pollingHours;
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the voterServices
	 */
	public String getVoterServices() {
		return voterServices;
	}

	/**
	 * @param voterServices the voterServices to set
	 */
	public void setVoterServices(String voterServices) {
		this.voterServices = voterServices;
	}

	/**
	 * @return the startDate
	 */
	public String getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public String getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the latitude
	 */
	public double getLatitude() {
		return latitude;
	}

	/**
	 * @param latitude the latitude to set
	 */
	public void setLatitude(double latitude) {
		this.latitude = latitude;
	}

	/**
	 * @return the longitude
	 */
	public double getLongitude() {
		return longitude;
	}

	/**
	 * @param longitude the longitude to set
	 */
	public void setLongitude(double longitude) {
		this.longitude = longitude;
	}

	/**
	 * @return String
	 */
	public String toString(){
		
			if(this.getName() == null) {
				this.name = "no Name";
				
			}
			
			return "Address: \n\n " 
			
			+ this.getAddresses() + "\n" 
			+ this.getName() + "\n" + 
			"Polling Hours: \n"
			+ this.getPollingHours() + "\n\n" +
			"General Information: \n" 
		    + this.getNotes() + " " 
			+ this.getVoterServices() + "\n\n" +
			"StartDate-EndDate: \n"
		    + this.getStartDate() + " " 
			+ this.getEndDate() + "\n\n" +
			"Coordinates: \n" 
 		    + this.getLatitude() + " " 
			+ this.getLongitude() + "\n";

		
		
	}
}
