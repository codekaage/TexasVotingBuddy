package application.model;

import java.util.ArrayList;
import org.json.*;

/**
 * The Office object contains the Office's name and Division ID.
 * As well as 2 ArrayLists of Roles and Levels.
 *
 * @author Andrew Neumann (obb447)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/9/22
 */

public class Office {
	private String strName;
	private String strDivisionID;
	private ArrayList<String> arrRoles;
	private ArrayList<String> arrLevels;
	private ArrayList<Integer> arrOfficialIndexes;
	private ArrayList<Division> arrDivisions;


	private JSONObject jsnDataSource;
	
	public Office()
	{
		arrRoles = new ArrayList<String>();
		arrLevels = new ArrayList<String>();
		arrOfficialIndexes = new ArrayList<Integer>() ;
		arrDivisions =new  ArrayList<Division>();
		setDataSource(null);
	}
	
	public Office(JSONObject jsnData)
	{
		setDataSource(jsnData);
		arrRoles = new ArrayList<String>();
		arrLevels = new ArrayList<String>();
		arrOfficialIndexes = new ArrayList<Integer>() ;
		arrDivisions =new  ArrayList<Division>();
		
		setName(jsnData.getString("name"));
		setDivisionID(jsnData.getString("divisionId"));
		
		JSONArray jsnRoles = jsnData.getJSONArray("roles");
		for (int x = 0; x < jsnRoles.length(); x++) 
		{
			arrRoles.add(jsnRoles.getString(x));
		}
		
		JSONArray jsnLevels = jsnData.getJSONArray("levels");
		for (int x = 0; x < jsnLevels.length(); x++) 
		{
			arrLevels.add(jsnLevels.getString(x));
		}
		
		JSONArray jsnIndices = jsnData.getJSONArray("officialIndices");
		for (int x = 0; x < jsnIndices.length(); x++) 
		{
			arrOfficialIndexes.add(jsnIndices.optInt(x));
		}
	}

	/**
	 * @return the strDivisionID
	 */
	public String getDivisionID() {
		return strDivisionID;
	}

	/**
	 * @param strDivisionID the strDivisionID to set
	 */
	public void setDivisionID(String strDivisionID) {
		this.strDivisionID = strDivisionID;
	}

	/**
	 * @return the jsnDataSource
	 */
	public JSONObject getDataSource() {
		return jsnDataSource;
	}

	/**
	 * @param jsnDataSource the jsnDataSource to set
	 */
	private void setDataSource(JSONObject jsnDataSource) {
		this.jsnDataSource = jsnDataSource;
	}
	
	/**
	 * @return the arrDivisions
	 */
	public ArrayList<Division> getDivisions() {
		return arrDivisions;
	}

	/**
	 * @param arrDivisions the arrDivisions to set
	 */
	public void setDivisions(ArrayList<Division> arrDivisions) {
		this.arrDivisions = arrDivisions;
	}
	
	/**
	 * @return the strName
	 */
	public String getName() {
		return strName;
	}

	/**
	 * @param strName the strName to set
	 */
	public void setName(String strName) {
		this.strName = strName;
	}

	/**
	 * @return the arrOfficialIndexes
	 */
	public ArrayList<Integer> getOfficialIndexes() {
		return arrOfficialIndexes;
	}
	
	/**
	 * @return the Official int at index
	 */
	public int getOfficialAtIndex(int index) {
		return arrOfficialIndexes.get(index);
	}
	
	/**
	 * @param arrOfficialIndexes the arrOfficialIndexes to set
	 */
	public void setOfficialIndexes(ArrayList<Integer> arrOfficialIndexes) {
		this.arrOfficialIndexes = arrOfficialIndexes;
	}

	/**
	 * @param newDivision
	 */
	public void addDivison(Division newDivision) 
	{
		arrDivisions.add(newDivision);
		
	}
	
	public String toString()
	{
		String strOut = "";
		String strTab = "\t";
		strOut += getName() + "\n";
		if(getDivisions().size() > 0 )
		{
			strOut += "Divisions: \n"; 
			for(int i = 0; i < getDivisions().size(); i++)
			{
				strOut += strTab  + getDivisions().get(i).getName() + "\n";
			}
		}
		return strOut;
	}

	

}
