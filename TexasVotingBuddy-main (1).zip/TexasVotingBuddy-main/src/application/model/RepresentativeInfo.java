package application.model;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * The top object for the information generated from an api call to https://civicinfo.googleapis.com/civicinfo/v2/representatives
 * This object contains an array of Officials ,Offices and Divisions objects.
 *
 * @author Andrew Neumann (obb447)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/9/22
 */

public class RepresentativeInfo 
{
	public static RepresentativeInfo repCurrent;
	private String strLine1;
	private String strCity;
	private String strState;
	private String strZip;
	private ArrayList<Office> arrOffices = new ArrayList<Office>();
	private ArrayList<Division> arrDivisions = new ArrayList<Division>();
	private ArrayList<Official> arrOfficials = new ArrayList<Official>();
	private JSONObject jsnData; 
	
	/**
	 * @param jsnData
	 */
	public RepresentativeInfo(JSONObject jsnData)
	{
		//Normalized input
		JSONObject jsnInput= jsnData.getJSONObject("normalizedInput");
		setLine1(jsnInput.getString("line1"));
		setCity(jsnInput.getString("city"));
		setState(jsnInput.getString("state"));
		setZip(jsnInput.getString("zip"));
		
		
		//uploadOfficials
		JSONArray jsnOfficials = jsnData.getJSONArray("officials");
		for (int i = 0; i < jsnOfficials.length(); i++) 
		{
			Official newOfficial = new Official(jsnOfficials.getJSONObject(i));
			arrOfficials.add(newOfficial);
		}
		
		//uploadOffices
		JSONArray jsnOffices = jsnData.getJSONArray("offices");
		for (int i = 0; i < jsnOffices.length(); i++) 
		{
			Office newOffice = new Office(jsnOffices.getJSONObject(i));
			for(int x = 0; x < newOffice.getOfficialIndexes().size(); x++) 
			{

				arrOfficials.get(newOffice.getOfficialAtIndex(x)).addOffice(newOffice);
			}
			arrOffices.add(newOffice);
		}
		
		int count = 0;
		JSONObject jsnDivisions = jsnData.getJSONObject("divisions");
		JSONArray arrKeys = jsnDivisions.names ();

		for (int i = 0; i < arrKeys.length (); i++) 
		{
		   
		   String strKey = arrKeys.getString (i); // Here's your key
		   Division newDivision =new  Division(jsnDivisions.getJSONObject (strKey));
		   arrDivisions.add(newDivision);// Here's your value
			newDivision.setKeyName(strKey);
			for(int x = 0; x < newDivision.getOffices().size(); x++) 
			{
				arrOffices.get(newDivision.getOfficeAtIndex(x)).addDivison(newDivision);

			}
		}

	}

	/**
	 * @return 
	 */
	public ArrayList<String> getDivisionsInOrder()
	{
		ArrayList<Division> arrDivisionKeys = (ArrayList<Division>) arrDivisions.clone();
		
		//sorting by size of string
		int intTop = 0;
		int intBot = 0;
		
        // Outer loop
        for (int i = 0; i < arrDivisionKeys.size(); i++)
        {
 
            // Inner nested loop pointing 1 index ahead
            for (int j = i + 1; j < arrDivisionKeys.size(); j++) 
            {
 
                // Checking elements
    			intTop = Count(arrDivisionKeys.get(i), '/');
    			intBot = Count(arrDivisionKeys.get(j), '/');
                if (intBot < intTop) {
 
                    // Swapping
					Division divTemp = arrDivisionKeys.get(i);
					Division divTemp2 = arrDivisionKeys.get(j);
					arrDivisionKeys.set(i, divTemp2);
					arrDivisionKeys.set(j, divTemp);
                }
            }
 
            // Printing sorted array elements
        }

		ArrayList<String> arrOutput = new ArrayList<String>();
		for (int i = 0 ; i < arrDivisionKeys.size(); i++)
		{
			arrOutput.add(arrDivisionKeys.get(i).getName());
		}
		
		return arrOutput;
	}
	
	
	/**
	 * @param divInput
	 * @param chrToken
	 * @return
	 */
	private int Count(Division divInput, char chrToken)
	{
		int intCount = 0;
		for (int i = 0; i < divInput.getKeyName().length(); i++) {
		    if (divInput.getKeyName().charAt(i) == chrToken) {
		    	intCount++;
		    }
		}
		return intCount;
		
	}
	
	//This will make tasks to download the officials photos from photoURL
	public void DownloadOfficialsPhotos()
	{
		for(Official off : getOfficials()) 
		{
			off.DownloadPhoto();
		}
	}
	
	/**
	 * @return the arrOfficials
	 */
	public ArrayList<Official> getOfficials() {
		return arrOfficials;
	}

	/**
	 * @param arrOfficials the arrOfficials to set
	 */
	public void setOfficials(ArrayList<Official> arrOfficials) {
		this.arrOfficials = arrOfficials;
	}

	/**
	 * @return the arrOffices
	 */
	public ArrayList<Office> getOffices() {
		return arrOffices;
	}

	/**
	 * @param arrOffices the arrOffices to set
	 */
	public void setOffices(ArrayList<Office> arrOffices) {
		this.arrOffices = arrOffices;
	}

	/**
	 * @return the arrDivisions
	 */
	public ArrayList<Division> getArrDivisions() {
		return arrDivisions;
	}

	/**
	 * @param arrDivisions the arrDivisions to set
	 */
	public void setArrDivisions(ArrayList<Division> arrDivisions) {
		this.arrDivisions = arrDivisions;
	}
	
	/**
	 * @return
	 */
	public ArrayList<Division> getDivisions() 
	{
		return arrDivisions;
	}
	
	/**
	 * @param arrDivisions
	 */
	public void setDivisions(ArrayList<Division> arrDivisions) 
	{
		this.arrDivisions = arrDivisions;
	}
	
	/**
	 * @return
	 */
	public String getState() 
	{
		return strState;
	}
	
	/**
	 * @param strState
	 */
	public void setState(String strState) 
	{
		this.strState = strState;
	}
	
	/**
	 * @return
	 */
	public String getCity() 
	{
		return strCity;
	}
	
	/**
	 * @param strCity
	 */
	public void setCity(String strCity) 
	{
		this.strCity = strCity;
	}
	
	/**
	 * @return
	 */
	public String getZip() 
	{
		return strZip;
	}
	
	/**
	 * @param strZip
	 */
	public void setZip(String strZip) 
	{
		this.strZip = strZip;
	}
	
	/**
	 * @return
	 */
	public String getLine1() 
	{
		return strLine1;
	}
	
	/**
	 * @param strLine1
	 */
	public void setLine1(String strLine1) 
	{
		this.strLine1 = strLine1;
	}
	
	/**
	 * @return
	 */
	public JSONObject getData() 
	{
		return jsnData;
	}
	
	/**
	 * @param jsnData
	 */
	public void setData(JSONObject jsnData) 
	{
		this.jsnData = jsnData;
	}
}
