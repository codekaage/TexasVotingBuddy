package application.model;

import javafx.beans.property.SimpleStringProperty;

/**
 * @author Varun Prasad (rgp799)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last Updated 11/25/2022
 */

public class ElectionObj {
	
	/**
	 * variable declarations
	 */
	private final SimpleStringProperty elecAddress;
	private final SimpleStringProperty elecPollingHours;
	private final SimpleStringProperty elecCoordinates;
	private final SimpleStringProperty elecStartDate;
	private final SimpleStringProperty elecEndDate;

	/**
	 * 	 ElectionObj with same parameters as variables but differently named for getters and setters as well as 
	 *  	representing the current object
	 * 
	 * @param Address
	 * @param PollingHours
	 * @param Coordinates
	 * @param StartDate
	 * @param EndDate
	 */
	public ElectionObj(String Address, String PollingHours, String Coordinates, String StartDate, String EndDate) {
		this.elecAddress = new SimpleStringProperty(Address);
		this.elecPollingHours = new SimpleStringProperty(PollingHours);
		this.elecCoordinates = new SimpleStringProperty(Coordinates);
		this.elecStartDate = new SimpleStringProperty(StartDate);
		this.elecEndDate = new SimpleStringProperty(EndDate);
	}
	
	/**
	 * setters and getters for Address - gets the address and sets it to to the SimpleStringProperty variable
	 *  Using SimpleStringProperty allows us to see the view of the variable(s) in TableView as it updates with 
	 *  the Election data
	 * 
	 * @return elecAddress (String)
	 */
	public String getElecAddress() {
		return elecAddress.get();
	}
	
		public void setElecAddress(String Address) {
			elecAddress.set(Address);
		}
			public SimpleStringProperty elecAddressProperty() {
				return elecAddress;
			}
			
	/**
	* setters and getters for Address - gets the address and sets it to to the SimpleStringProperty variable
	*  Using SimpleStringProperty allows us to see the view of the variable(s) in TableView as it updates with 
	*  the Election data
	* 
	* @return elecPollingHours (String)
	*/
	public String getElecPollingHours() {
		return elecPollingHours.get();
	}
	
		public void setElecPollingHours(String PollingHours) {
			elecPollingHours.set(PollingHours);
		}
			public SimpleStringProperty elecPollingHoursProperty() {
				return elecPollingHours;
			}
			
	/**
	* 	setters and getters for Coordinates - gets the coordinates and sets it to a 
	* 	SimpleStringProperty variable
	* 
	* @return elecCoordinates (String)
	*/
	public String getElecCoordinates() {
		return elecCoordinates.get();
	}
	
		public void setElecCoordinates(String Coordinates) {
			elecCoordinates.set(Coordinates);
		}
			public SimpleStringProperty elecCoordinatesProperty() {
				return elecCoordinates;
			}
	
	/**
	 * 	setters and getters for StartDate - gets the start date of the poll and sets it to a 
	 *	SimpleStringProperty variable
	 *
	 * @return elecStartDate (String)
	 */
	public String getElecStartDate() {
		return elecStartDate.get();
	}
	
		public void setElecStartDate(String StartDate) {
			elecStartDate.set(StartDate);
		}
			public SimpleStringProperty elecStartDateProperty() {
				return elecStartDate;
			}
			
	/**
	* 	setters and getters for EndDate - gets the end date of the poll and sets it to a 
	*	SimpleStringProperty variable
	*
	* @return elecStartDate (String)
	*/
	public String getElecEndDate() {
		return elecEndDate.get();
	}
	
		public void setElecEndDate(String EndDate) {
			elecEndDate.set(EndDate);
		}
			public SimpleStringProperty elecEndDateProperty() {
				return elecEndDate;
			}
}
