package application.model;

import java.util.ArrayList;

import org.json.JSONObject;
/**
 * Sorts Data into objects and toString()
 *
 * @author Diego Enriquez (dyg458)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/29/22
 */
public class ElectionAdministration {

	private String name;
	private String url;
	private String elecRegUrl;
	private String elecRegConfUrl;
	private String absVotUrl;
	private String ballotInfoUrl;
	private ArrayList<PhysicalAddress> addresses = new ArrayList<PhysicalAddress>();
	
	/**
	 * @param object
	 */
	public ElectionAdministration(JSONObject object) {
		
		
		
		JSONObject jsnphyAddress = object.getJSONObject("physicalAddress");
		PhysicalAddress physicalAddress = new PhysicalAddress(jsnphyAddress);
		addresses.add(physicalAddress);
		
		this.name = object.optString("name");
		this.url= object.optString("electionInfoUrl");
		this.elecRegUrl = object.optString("electionRegistrationUrl");
		this.elecRegConfUrl = object.optString("electionRegistrationConfirmationUrl");
		this.absVotUrl = object.optString("absenteeVotingInfoUrl");
		this.ballotInfoUrl = object.optString("ballotInfoUrl");
		
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the elecRegUrl
	 */
	public String getElecRegUrl() {
		return elecRegUrl;
	}

	/**
	 * @param elecRegUrl the elecRegUrl to set
	 */
	public void setElecRegUrl(String elecRegUrl) {
		this.elecRegUrl = elecRegUrl;
	}

	/**
	 * @return the elecRegConfUrl
	 */
	public String getElecRegConfUrl() {
		return elecRegConfUrl;
	}

	/**
	 * @param elecRegConfUrl the elecRegConfUrl to set
	 */
	public void setElecRegConfUrl(String elecRegConfUrl) {
		this.elecRegConfUrl = elecRegConfUrl;
	}

	/**
	 * @return the absVotUrl
	 */
	public String getAbsVotUrl() {
		return absVotUrl;
	}

	/**
	 * @param absVotUrl the absVotUrl to set
	 */
	public void setAbsVotUrl(String absVotUrl) {
		this.absVotUrl = absVotUrl;
	}

	/**
	 * @return the ballotInfoUrl
	 */
	public String getBallotInfoUrl() {
		return ballotInfoUrl;
	}

	/**
	 * @param ballotInfoUrl the ballotInfoUrl to set
	 */
	public void setBallotInfoUrl(String ballotInfoUrl) {
		this.ballotInfoUrl = ballotInfoUrl;
	}

	/**
	 * @return the addresses
	 */
	public ArrayList<PhysicalAddress> getAddresses() {
		return addresses;
	}

	/**
	 * @param addresses the addresses to set
	 */
	public void setAddresses(ArrayList<PhysicalAddress> addresses) {
		this.addresses = addresses;
	}
	
	
	
	
	
	public String toString() {
		
		if(this.getName() == null) {
			return "no Name";
		}
		
		return "BRUH" + this.getAddresses() + " " + this.getName() + this.getUrl() + "\n" 
				+ this.getElecRegUrl() + " " + this.getElecRegConfUrl() + "\n"
				+ this.getAbsVotUrl() + " " + this.getBallotInfoUrl();
	
	}
	
	
	
	
}
