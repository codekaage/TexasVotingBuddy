package application.model;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;
/**
 * Sorts Data into objects and toString()
 *
 * @author Diego Enriquez (dyg458)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/29/22
 */
public class ContestObj {

	private String type; 
	private String ballotTitle;
	private String office;
	private JSONArray Level; //BRUH
	private JSONArray role;   //BRUH
	private long numberElected;
	private long numberVotingFor;
	private JSONArray source; //BRUH
	
	private ArrayList<District> districts = new ArrayList<District>();
	private ArrayList<Candidate> candidate = new ArrayList<Candidate>();

	
	/**
	 * @param jsonObject
	 */
	public ContestObj(JSONObject jsonObject) {
		
		
		this.type = jsonObject.optString("type");
		this.ballotTitle = jsonObject.optString("ballotTitle");
		this.office = jsonObject.optString("office");
		
	    this.Level = jsonObject.optJSONArray("level");
		this.role = jsonObject.optJSONArray("roles");
		
		JSONObject jsonDistrict = jsonObject.optJSONObject("district"); 
		District district = new District(jsonDistrict); //create new District object;
		districts.add(district);
		
		this.numberElected = jsonObject.optLong("numberElected");
		this.numberVotingFor = jsonObject.optLong("numberElected");
		
		this.source = jsonObject.optJSONArray("sources");
		
		
		
		//candidate info
		JSONArray jsonCandidate = jsonObject.optJSONArray("candidates");
		Candidate candidates;
		for(int i = 0; i < jsonCandidate.length(); i++) {
		   
			 candidates = new Candidate(jsonCandidate.getJSONObject(i), i); //create new District object;
		     candidate.add(candidates);
		}
		
	}

	/**
	 * @return the type
	 */
	public String getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(String type) {
		this.type = type;
	}

	/**
	 * @return the ballotTitle
	 */
	public String getBallotTitle() {
		return ballotTitle;
	}

	/**
	 * @param ballotTitle the ballotTitle to set
	 */
	public void setBallotTitle(String ballotTitle) {
		this.ballotTitle = ballotTitle;
	}

	/**
	 * @return the office
	 */
	public String getOffice() {
		return office;
	}

	/**
	 * @param office the office to set
	 */
	public void setOffice(String office) {
		this.office = office;
	}

	/**
	 * @return the typeLevel
	 */
	public JSONArray getLevel() {
		return Level;
	}

	/**
	 * @param typeLevel the typeLevel to set
	 */
	public void setLevel(JSONArray typeLevel) {
		this.Level = typeLevel;
	}

	/**
	 * @return the role
	 */
	public JSONArray getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(JSONArray role) {
		this.role = role;
	}

	/**
	 * @return the numberElected
	 */
	public long getNumberElected() {
		return numberElected;
	}

	/**
	 * @param numberElected the numberElected to set
	 */
	public void setNumberElected(long numberElected) {
		this.numberElected = numberElected;
	}

	/**
	 * @return the numberVotingFor
	 */
	public long getNumberVotingFor() {
		return numberVotingFor;
	}

	/**
	 * @param numberVotingFor the numberVotingFor to set
	 */
	public void setNumberVotingFor(long numberVotingFor) {
		this.numberVotingFor = numberVotingFor;
	}

	/**
	 * @return the source
	 */
	public JSONArray getSource() {
		return source;
	}

	/**
	 * @param source the source to set
	 */
	public void setSource(JSONArray source) {
		this.source = source;
	}

	/**
	 * @return the candidate
	 */
	public ArrayList<Candidate> getCandidate() {
		return this.candidate;
	}

	/**
	 * @param candidate the candidate to set
	 */
	public void setCandidate(ArrayList<Candidate> candidate) {
		this.candidate = candidate;
	}

	/**
	 * @return the districts
	 */
	public ArrayList<District> getDistricts() {
		return districts;
	}

	/**
	 * @param districts the districts to set
	 */
	public void setDistricts(ArrayList<District> districts) {
		this.districts = districts;
	}
	/**
	 * @return String
	 */
	public String toString() {

		return "CONTESTINFO: \n"
				+ this.getType() + "\n"
				+ this.getBallotTitle() + "\n"
				+ this.getOffice() + "\n"
				+ this.getLevel() + "\n"
				+ this.getRole() + "\n"
				+ this.getDistricts() + "\n"
				+ this.getNumberElected() + "\n"
				+ this.getNumberVotingFor() + "\n"
				+ this.getSource() + "\n\n"
				
				+ "CANDIDATEINFO(GENERAL): \n\n" 
				+ this.getCandidate() + "\n";
		
			    
		


	}
	
	
	
	
	
	
	
	
}
