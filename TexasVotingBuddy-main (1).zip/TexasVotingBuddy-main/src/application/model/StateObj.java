package application.model;

import java.util.ArrayList;

import org.json.JSONObject;
/**
 * Sorts Data into objects and toString()
 *
 * @author Diego Enriquez (dyg458)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/29/22
 */
public class StateObj {

	private String name;
	private ArrayList<ElectionAdministration> admin = new ArrayList<ElectionAdministration>();
	
	
	/**
	 * @param jsonObject
	 */
	public StateObj(JSONObject jsonObject) {
		
		
		JSONObject jsnElecAdmin = jsonObject.getJSONObject("electionAdministrationBody");
		ElectionAdministration elecAdmin = new ElectionAdministration(jsnElecAdmin);
		admin.add(elecAdmin);
		
		this.name = jsonObject.optString("name");
		
		
		
		
		
		// TODO Auto-generated constructor stub
	}
	/**
	 * @return the admin
	 */
	public ArrayList<ElectionAdministration> getAdmin() {
		return admin;
	}
	/**
	 * @param admin the admin to set
	 */
	public void setAdmin(ArrayList<ElectionAdministration> admin) {
		this.admin = admin;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}




	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return String
	 */
	public String toString() {
		if(this.getName() == null) {
			this.name = "no Name";
		}
		return this.getAdmin() + "\n " + this.getName();
	}
	

}
