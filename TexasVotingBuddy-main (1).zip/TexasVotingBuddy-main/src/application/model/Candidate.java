package application.model;

import org.json.JSONArray;
import org.json.JSONObject;
/**
 * Sorts Data into objects and toString()
 *
 * @author Diego Enriquez (dyg458)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/29/22
 */
public class Candidate {

	private String name;
	private String party;
	private String url;
	private String email;
	private JSONArray channels;
	
	/**
	 * @param jsonObject, index 
	 */
	public Candidate(JSONObject jsonObject, int index) {
		
		
	  
	    this.name = jsonObject.optString("name");
	    this.party = jsonObject.optString("party");
	    this.url = jsonObject.optString("candidateUrl");
	    this.email = jsonObject.optString("email");
	    //this.channels = jsonObject.getJSONArray("channels");
	    
	    
	    
	    
	}

	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}


	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}

	/**
	 * @return the party
	 */
	public String getParty() {
		return party;
	}

	/**
	 * @param party the party to set
	 */
	public void setParty(String party) {
		this.party = party;
	}

	/**
	 * @return the url
	 */
	public String getUrl() {
		return url;
	}

	/**
	 * @param url the url to set
	 */
	public void setUrl(String url) {
		this.url = url;
	}

	/**
	 * @return the email
	 */
	public String getEmail() {
		return email;
	}


	/**
	 * @param email the email to set
	 */
	public void setEmail(String email) {
		this.email = email;
	}


	/**
	 * @return the channels
	 */
	public JSONArray getChannels() {
		return channels;
	}


	/**
	 * @param channels the channels to set
	 */
	public void setChannels(JSONArray channels) {
		this.channels = channels;
	}
	
	/**
	 * @return String
	 */
	public String toString() {
		
		if(this.getUrl() == null)
		{
			this.setUrl("nothing");
			
		}
		if(this.getEmail() == null)
		{
			this.setEmail("nada");
			
		}
		
		
		return " ------Individual Candidate Info------ \n\n" 
				+ "Name: \n" + 
				this.getName() + "\n\n"
				+ "PartyType: \n"
				+ this.getParty() + "\n\n"
				+ "Url/Email Information: \n\n"
				+ this.getUrl()
				+ this.getEmail() + "\n";
				
		
	}
	
	
	
}
