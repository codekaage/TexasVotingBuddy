package application.model;
import java.util.ArrayList;
import org.json.JSONArray;
import org.json.JSONObject;
/**
 * The top object for the information generated from an api call to https://civicinfo.googleapis.com/civicinfo/v2/representatives
 * This object contains an array of Officials ,Offices and Divisions objects.
 *
 * @author Diego Enriquez (dyg458)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/18/22
 */
public class Election { 

	/**
	 * variable declarations 
	 */
	public static Election elecCurrent;
	private String strLine1;
	private String strCity;
	private String strState;
	private String strZip;
	private ArrayList<Poll> locations = new ArrayList<Poll>(); 
	private ArrayList<ContestObj> contest = new ArrayList<ContestObj>();				
	private ArrayList<StateObj> State = new ArrayList<StateObj>();						
	private JSONObject jsnData; 
	
	
	/**
	 * Election object takes in jsnData
	 * 
	 * @param jsnData
	 */
	public Election(JSONObject jsnData)
	{
		/**
		 * Normalized Input
		 */
		JSONObject jsnInput= jsnData.getJSONObject("normalizedInput");
		setLine1(jsnInput.getString("line1"));
		setCity(jsnInput.getString("city"));
		setState(jsnInput.getString("state"));
		setZip(jsnInput.getString("zip"));
		
	
		
		/**
		 * uploadPollingLocations
		 */
		JSONArray jsnPoll = jsnData.getJSONArray("pollingLocations"); 	
		
		for (int i = 0; i < jsnPoll.length(); i++) 
		{
			Poll newPoll = new Poll(jsnPoll.getJSONObject(i)); //create a new Polling Object
			locations.add(newPoll);
		}
		
		/**
		 * uploadOffices
		 */
		JSONArray jsnContest = jsnData.getJSONArray("contests");
		for (int i = 0; i < jsnContest.length(); i++) 
		{
			ContestObj newContest = new ContestObj(jsnContest.getJSONObject(i));
			
			contest.add(newContest); //arrayList contest
		}
		
		/**
		 * 
		 */
		JSONArray jsnState = jsnData.getJSONArray("state"); 
		for (int i = 0; i < jsnState.length(); i++) 
		{
			StateObj state = new StateObj(jsnState.getJSONObject(i)); 
			
			State.add(state);
		}

	}	
	
	/**
	 * 	getPollLocation returns locations 
	 * 
	 * @return locations 
	 */
	public ArrayList<Poll> getPollLocation() {
		return locations;
	}

	
	/**
	 * 	setPollLocation takes in param ArraList<Poll> locations then sets locations to the current locations object
	 * 
	 * @param locations (ArrayList<Poll>)
	 */
	public void setPollLocation(ArrayList<Poll> locations) {
		this.locations = locations;
	}

	
	/**
	 * 	getContest returns contest object
	 * 
	 * @return contest (ArrayList<ContestObj>)
	 */
	public ArrayList<ContestObj> getContest() {
		return contest;
	}

	
	/**
	 * 	setContest takes param ArrayList<ContestObj> contest then sets contests to the current contest object
	 * 
	 * @param contest
	 */
	public void setContest(ArrayList<ContestObj> contest) {
		this.contest = contest;
	}

	
	/**
	 * 	getState returns strState
	 * 
	 * @return
	 */
	public String getState() {
		return strState;
	}

	
	/**
	 * 	setState takes in a string parameter then sets string as the current strState object
	 * 
	 * @param string
	 */
	public void setState(String string) {
		this.strState = string;
	}

	/**
	 * 	getCity returns strCity
	 * 
	 * @return
	 */
	public String getCity() 
	{
		return strCity;
	}
	
	/**
	 * 	setCity takes in param strCity (String) then sets strCity to the current strCity object
	 * 
	 * @param strCity
	 */
	public void setCity(String strCity) 
	{
		this.strCity = strCity;
	}
	
	/**
	 * 	getZip returns strZip
	 * 
	 * @return strZip
	 */
	public String getZip() 
	{
		return strZip;
	}
	
	/**
	 * 	setZip takes in a parameter strZip then sets strZip to the current strZip object
	 * 
	 * @param strZip
	 */
	public void setZip(String strZip) 
	{
		this.strZip = strZip;
	}
	
	/**
	 * 	getLine1 returns strLine1
	 * 
	 * @return strLine1
	 */
	
	public String getLine1() 
	{
		return strLine1;
	}
	
	/**
	 * 	setLine1 takes in a parameter strLine1 then sets strLine1 to the current strLine1 object 
	 * 
	 * @param strLine1
	 */
	public void setLine1(String strLine1) 
	{
		this.strLine1 = strLine1;
	}
	
	/**
	 * 	getData returns jsnData
	 * 
	 * @return jsnData (JSONObject)
	 */
	public JSONObject getData() 
	{
		return jsnData;
	}
	
	/**
	 * 	setData sets takes in param JSONObject jsnData and sets jsnData to the current jsnData object
	 * 
	 * @param jsnData
	 */
	public void setData(JSONObject jsnData) 
	{
		this.jsnData = jsnData;
	}

	/**
	 * 	getStrState returns strState
	 * 
	 * @return strState (String)
	 */
	public String getStrState() {
		return strState;
	}

	/**
	 * 	setStrState takes parameter strState then sets strState to the current strState object
	 * 
	 * @param strState
	 */
	public void setStrState(String strState) {
		this.strState = strState;
	}
	
	
	
}
