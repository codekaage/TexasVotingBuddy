package application.model;

import org.json.JSONObject;
/**
 * Sorts Data into objects and toString()
 *
 * @author Diego Enriquez (dyg458)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/29/22
 */
public class District {

	private String name; 
	private String scope;
	
	/**
	 * @param jsonDistrict
	 */
	public District(JSONObject jsonDistrict) {
	
		this.name = jsonDistrict.optString("name");
		this.scope = jsonDistrict.optString("scope");
		
	}
	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}


	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}


	/**
	 * @return the scope
	 */
	public String getScope() {
		return scope;
	}


	/**
	 * @param scope the scope to set
	 */
	public void setScope(String scope) {
		this.scope = scope;
	}
	/**
	 * @return String
	 */
	public String toString() {
		
			return " DISTRICT: " + 
					this.getName() + "\n"
					+ this.getScope();	
	}
	
}
