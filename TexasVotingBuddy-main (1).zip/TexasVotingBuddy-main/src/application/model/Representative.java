package application.model;

import javafx.beans.property.SimpleStringProperty;
import javafx.scene.image.ImageView;

/**
 * 
 * 
 * @author Ryan Brown (kkw582)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last Updated 11/25/2022
 */
public class Representative {

	private ImageView photo;
	private final SimpleStringProperty repName;
	private final SimpleStringProperty repParty;
	private final SimpleStringProperty repOffice;
	private final SimpleStringProperty repDivision;
	private final SimpleStringProperty repURL;
	private final SimpleStringProperty repEmail;
	private final SimpleStringProperty repChannel;
	
	public Representative(ImageView photo, String name, String party, String office, String division, String URL, String email, String channel) {
		
		this.photo = photo;
		this.repName = new SimpleStringProperty(name);
		this.repParty = new SimpleStringProperty(party);
		this.repOffice = new SimpleStringProperty(office);
		this.repDivision = new SimpleStringProperty(division);
		this.repURL = new SimpleStringProperty(URL);
		this.repEmail = new SimpleStringProperty(email);
		this.repChannel = new SimpleStringProperty(channel);
		
	}

	/**
	 * 
	 * @return
	 */
	public ImageView getPhoto() {
		return photo;
	}

	/**
	 * 
	 * @param photo
	 */
	public void setPhoto(ImageView photo) {
		this.photo = photo;
	}

	/**
	 * 
	 * @return
	 */
	public String getRepName() {
		return repName.get();
	}
	
	/**
	 * 
	 * @param name
	 */
	public void setRepName(String name) {
		repName.set(name);
	}
	
	/**
	 * 
	 * @return
	 */
	public SimpleStringProperty repNameProperty() {
		return repName;
	}

	/**
	 * 
	 * @return
	 */
	public String getRepParty() {
		return repParty.get();
	}
	
	/**
	 * 
	 * @param party
	 */
	public void setRepParty(String party) {
		repParty.set(party);
	}
	
	/**
	 * 
	 * @return
	 */
	public SimpleStringProperty repPartyProperty() {
		return repParty;
	}

	/**
	 * 
	 * @return
	 */
	public String getRepOffice() {
		return repOffice.get();
	}
	
	/**
	 * 
	 * @param Office
	 */
	public void setRepOffice(String Office) {
		repOffice.set(Office);
	}
	
	/**
	 * 
	 * @return
	 */
	public SimpleStringProperty repOfficeProperty() {
		return repOffice;
	}

	/**
	 * 
	 * @return
	 */
	public String getRepDivision() {
		return repDivision.get();
	}
	
	/**
	 * 
	 * @param division
	 */
	public void setRepDivision(String division) {
		repDivision.set(division);
	}
	
	/**
	 * 
	 * @return
	 */
	public SimpleStringProperty repDivisionProperty() {
		return repDivision;
	}

	/**
	 * 
	 * @return
	 */
	public String getRepURL() {
		return repURL.get();
	}
	
	/**
	 * 
	 * @param url
	 */
	public void setRepURL(String url) {
		repURL.set(url);
	}
	
	/**
	 * 
	 * @return
	 */
	public SimpleStringProperty repURLProperty() {
		return repURL;
	}

	/**
	 * 
	 * @return
	 */
	public String getRepEmail() {
		return repEmail.get();
	}
	
	/**
	 * 
	 * @param email
	 */
	public void setRepEmail(String email) {
		repEmail.set(email);
	}
	
	/**
	 * 
	 * @return
	 */
	public SimpleStringProperty repEmailProperty() {
		return repEmail;
	}

	/**
	 * 
	 * @return
	 */
	public String getRepChannel() {
		return repChannel.get();
	}
	
	/**
	 * 
	 * @param channel
	 */
	public void setRepChannel(String channel) {
		repChannel.set(channel);
	}
	
	/**
	 * 
	 * @return
	 */
	public SimpleStringProperty repChannelProperty() {
		return repChannel;
	}
	
}
