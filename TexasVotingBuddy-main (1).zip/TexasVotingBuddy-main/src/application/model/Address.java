package application.model;

import org.json.JSONArray;
import org.json.JSONObject;
/**
 * Sorts Data into objects and toString()
 *
 * @author Diego Enriquez (dyg458)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/29/22
 */
public class Address{

	private String locationName;
	private String line1;
	private String city;
	private String state;
	private String zip;
	/**
	 * @param jsnAddress
	 */
	public Address(JSONObject jsnAddress) {
		
		this.locationName = jsnAddress.getString("locationName");
		this.line1 = jsnAddress.getString("line1");
		this.city = jsnAddress.getString("city");
		this.state = jsnAddress.getString("state");  //FIXME
		this.zip = jsnAddress.getString("zip");
		
		// TODO Auto-generated constructor stub
	}

	/**
	 * @return the locationName
	 */
	public String getLocationName() {
		return locationName;
	}

	/**
	 * @param locationName the locationName to set
	 */
	public void setLocationName(String locationName) {
		this.locationName = locationName;
	}

	/**
	 * @return the line1
	 */
	public String getLine1() {
		return line1;
	}

	/**
	 * @param line1 the line1 to set
	 */
	public void setLine1(String line1) {
		this.line1 = line1;
	}

	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}

	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}

	/**
	 * @return the state
	 */
	public String getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(String state) {
		this.state = state;
	}

	/**
	 * @return the zip
	 */
	public String getZip() {
		return zip;
	}

	/**
	 * @param zip the zip to set
	 */
	public void setZip(String zip) {
		this.zip = zip;
	}
	/**
	 * @return String
	 */
	public String toString()
	{
       return this.getLocationName() + " " + this.getLine1() + "\n" 
    		   + this.getCity() + " " + this.getState() + " " + this.getZip();
		
	}
	
	
	
	
}
