package application.model;

import org.json.JSONObject;
/**
 * The Channel object contains the Channel's name and ID.
 *
 * @author Andrew Neumann (obb447)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/9/22
 */
class Channel
{
    private String strType; 
    private String strID;
    
    public Channel()
    {
    	
    }
    public Channel(JSONObject data)
    {
    	setType(data.getString("type"));
    	setID(data.getString("id"));
    }

	/**
	 * @return the strID
	 */
	public String getID() 
	{
		return strID;
	}
	
	/**
	 * @param strID the strID to set
	 */
	public void setID(String strID) 
	{
		this.strID = strID;
	}
	
	/**
	 * @return the strType
	 */
	public String getType() 
	{
		return strType;
	}
	
	/**
	 * @param strType the Type to set
	 */
	public void setType(String strType) 
	{
		this.strType = strType;
	}

	public String toString()
	{
		String strOut = "";
		strOut += strID + " @"+ strType;
		return strOut;
	}
 }
