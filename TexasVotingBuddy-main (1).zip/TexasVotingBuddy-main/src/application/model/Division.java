package application.model;

import java.util.ArrayList;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Division object
 * 
 * @author Andrew Neumann (obb447)
 * UTSA CS 3443 - TexasVotingBuddy
 * Fall 2022
 * Last updated 11/9/22
 */

public class Division 
{

	private String strIndex;
	private String strName;
	private ArrayList<Integer> arrOffices;
	private String strKeyName;
	
	public Division()
	{
		setOffices(new ArrayList<Integer>());
		
	}
	
	/**
	 * @param jsnData
	 */
	public Division(JSONObject jsnData)
	{
		setOffices(new ArrayList<Integer>());
		strName = jsnData.getString("name");
		JSONArray arrOffices = jsnData.optJSONArray("officeIndices");
		if(arrOffices != null)
		{
			for (int i = 0; i < arrOffices.length(); i++) 
			{
				getOffices().add(arrOffices.getInt(i));
			}
		}
		
		
	}

	/**
	 * @return the arrOffices
	 */
	public ArrayList<Integer> getOffices() 
	{
		return arrOffices;
	}
	
	/**
	 *  @param index int
	 * @return the Offices as int at index
	 */
	public int getOfficeAtIndex(int index) 
	{
		return arrOffices.get(index);
	}

	/**
	 * @param arrOffices the arrOffices to set
	 */
	public void setOffices(ArrayList<Integer> arrOffices) 
	{
		this.arrOffices = arrOffices;
	}

	/**
	 * @return the strIndex
	 */
	public String getIndex() {
		return strIndex;
	}

	/**
	 * @param strIndex the strIndex to set
	 */
	public void setIndex(String strIndex) {
		this.strIndex = strIndex;
	}

	/**
	 * @return the strName
	 */
	public String getName() {
		return strName;
	}

	/**
	 * @param strName the strName to set
	 */
	public void setName(String strName) {
		this.strName = strName;
	}

	/**
	 * @return the strKeyName
	 */
	public String getKeyName() {
		return strKeyName;
	}

	/**
	 * @param strKeyName the strKeyName to set
	 */
	public void setKeyName(String strKeyName) {
		this.strKeyName = strKeyName;
	}
	
	public String toString()
	{
		return strName;
	}
	
}
