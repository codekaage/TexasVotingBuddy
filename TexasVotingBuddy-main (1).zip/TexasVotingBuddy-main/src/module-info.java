module TexasVotingBuddy {
	requires javafx.controls;
	requires javafx.fxml;
	requires org.json;
	requires javafx.base;
	requires javafx.graphics;
	requires javafx.web;
	requires java.logging;
	
	opens application to javafx.graphics, javafx.fxml;
	opens application.model to javafx.graphics, javafx.fxml, javafx.base;
	opens application.controller to javafx.graphics, javafx.fxml;
}
