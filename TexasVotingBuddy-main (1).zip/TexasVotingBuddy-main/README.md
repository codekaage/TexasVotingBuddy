# TexasVotingBuddy
This tool will help people decide who to vote for
